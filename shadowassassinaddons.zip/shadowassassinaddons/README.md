# soshimeeaddons
A [ChatTriggers](https://chattriggers.com/) module. Focused on Hypixel SkyBlock Dungeons (especially F7).

Join my Discord server, [SkyBlockY](https://discord.gg/DqPReM4mwZ), or your (eye)balls will explode.

"Made in Korea"

Questions that were never asked but will be answered:
- Why did you upload this to GitHub?—Ratters impersonating me
- Why is there no feature list?—To trick people into joining my Discord server
- Why does this question exist?—Looks less awkward to have 3 or more questions
